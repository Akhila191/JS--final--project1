/* ****************** */
/* syntax */
/* ****************** */

export function Component1() {
  return (
    <h4>Component 1</h4>
  )
}

export function Component2() {
  return (
    <h4>Component 2</h4>
  )
}

export default function Component() {
  return (
    <h4>Component</h4>
  )
}