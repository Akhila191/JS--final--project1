import "./index.scss"

function Index() {
  return <footer>Copyright © 2018 All rights reserved. Design: Rakesh</footer>;
}

export default Index;