import "./index.scss"

function Index() {
  return <div className="page_not_found_page wrapper_box">
    <h3>404 Error | Page Not Found!</h3>
    <a className="primary_btn" href="/">Back to Home</a>
  </div>;
}

export default Index;