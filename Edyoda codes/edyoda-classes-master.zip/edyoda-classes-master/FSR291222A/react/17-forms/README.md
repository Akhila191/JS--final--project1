## Forms | PropTypes
---
- Default value to inputs
- Handling errors
- Validate a form
- Clearing/Reset inputs

- Controlled Components > pass props
- Uncontrolled component > without any props, just render html

- PropTypes
  - `npm install --save prop-types`
  - https://www.npmjs.com/package/prop-types