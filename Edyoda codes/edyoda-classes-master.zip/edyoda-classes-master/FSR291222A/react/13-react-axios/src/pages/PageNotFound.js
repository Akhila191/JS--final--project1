function PageNotFound() {
  return <div className="PageNotFound">
    <h3>PageNotFound Page</h3>
    <br />
    <a href="/">Back to Home</a>
  </div>
}

export default PageNotFound;
