function Footer() {
  return <footer>Made with 💖 & 🍵 in India!</footer>;
}

export default Footer;