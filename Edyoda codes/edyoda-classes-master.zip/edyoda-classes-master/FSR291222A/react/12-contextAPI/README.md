authContext > Store All the Data
App
Header
Home
Login 
