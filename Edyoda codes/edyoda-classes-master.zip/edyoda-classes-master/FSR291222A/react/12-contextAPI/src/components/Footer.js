function Footer() {
  return (
    <div className="Footer">
      <p>Made with ❤️ in Bangalore, India!</p>
    </div>
  );
}

export default Footer;
