import { createContext } from "react";

const authContenxt = createContext({})

export default authContenxt;