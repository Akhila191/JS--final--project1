function Icon(props) {
  return <a href={props.href} target="_blank"><i className={props.icon}></i></a>
}

export default Icon;