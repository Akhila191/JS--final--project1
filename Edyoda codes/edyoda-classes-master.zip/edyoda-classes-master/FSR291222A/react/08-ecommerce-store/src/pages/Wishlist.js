function Wishlist() {
  return (
    <div>
      <h3>Wishlist Page</h3>
    </div>
  );
}

export default Wishlist;
