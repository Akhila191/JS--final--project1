function About() {
  return (
    <div>
      <h3>About Page</h3>
    </div>
  );
}

export default About;
