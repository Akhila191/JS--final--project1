alert("Hello from external JS!");
console.log("Hello from external JS!");