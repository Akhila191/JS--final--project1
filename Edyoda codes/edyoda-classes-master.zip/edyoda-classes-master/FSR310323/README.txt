HTML Classes content will go here.

----------
LINKS
----------
PPT-1:
https://docs.google.com/presentation/d/1QRy1Y8AjWaodD2kkQPKjcOOFXcUi0KAUdE6zg-kDW9s/edit?usp=sharing
PPT-2:
https://docs.google.com/presentation/d/1jAyAEsduMUbPO5PKUFNYpAd3iqxyEd6xv7REANr656k/edit?usp=sharing

Whatsapp Group: 
https://chat.whatsapp.com/GBacdv15wsVKu1Ll4ugQcb

----------
SHORTCUTS
----------
Ctrl + z > Undo
Ctrl + [ > Move code to left side
Ctrl + ] > Move code to right side
Win + .  > Smily window
Alt + Shift + ↓ > Duplicate line / lines (need to select)
Alt + ↓ > Move line(s) down
! + Tab/Enter > Create html skeleton
Ctrl + / > Toggle comments (HTML, CSS, JS)
Ctrl + d > Select next highlighted

----------
💡NOTES
----------
⭐ Don't try to remember the code, 
  understand the logic

<hr /> ✅
<hr>lsjdflsdfl</hr> ❌

VS Code > Editing
Browser > Rendering

